#include<stdio.h>
#include <stdlib.h>
#include "output.h"

int main(int argc, char* argv[]){
    //gcc -g -std=c99 -Wall -Wshadow -Wvla -pedantic *.c -o pa2
    
    if(argc != 5){
        printf("\nargc: %d", argc);
        fprintf(stderr, "\nInvalid number of input or ouput files");
        return EXIT_FAILURE;
    }

    FILE* f = fopen(argv[1], "r");
    if(f == NULL){
        fprintf(stderr, "input 1 fopen unsuccessful");
        return EXIT_FAILURE;
    }
    FILE* fw = fopen(argv[2], "w");
    if(fw == NULL){
        fprintf(stderr, "\noutput 1 fopen unsuccessful\n");
        fclose(f);
        return EXIT_FAILURE;
    }
    FILE* fdim = fopen(argv[3], "w");
    if(fdim == NULL){
        fprintf(stderr, "\noutput 2 fopen unsuccessful\n");
        fclose(f);
        fclose(fw);
        return EXIT_FAILURE;
    }
    FILE* fpck = fopen(argv[4], "w");
    if(fpck == NULL){
        fprintf(stderr, "\noutput 3 fopen unsuccessful\n");
        fclose(f);
        fclose(fw);
        fclose(fdim);
        return EXIT_FAILURE;
    }
    
    // Node* head = (Node*)malloc(sizeof(*head));
    Node* head = NULL;
    head = filetotree(f);

    //ouput 1
    postorder(head, fw);

    //output 2
    dimension(head);
    dim_po(head, fdim);

    //output 3
    head->xcor = 0;
    head->ycor = 0;
    packing(head, 0, 0);
    printleaf(head, fpck);

    //Memory leak?   
    freenode(head);
    fclose(f);
    fclose(fw);
    fclose(fdim);
    fclose(fpck);

    return EXIT_SUCCESS;
}
