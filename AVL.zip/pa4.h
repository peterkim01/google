#include <stdlib.h>
#include <stdio.h>

int readkey(FILE* fp);
char readid(FILE* fp);
void printpreorder(Tnode* root, FILE* fw);
void freenode(Tnode* head);

Tnode* buildtree(FILE* fp);
void freenode(Tnode* head);
Tnode* searchandinsert(Tnode **root, int key);
Tnode* clock_rotation(Tnode* root);
Tnode* anticlock_rotation(Tnode* root);
Tnode* searchandbal(Tnode* root, Tnode* proot, int key);
// Tnode* searchandbal(Tnode* root, Tnode* proot, int key, int *tempbal);
Tnode* findimpred(Tnode* curr);
Tnode *balance(Tnode *pcurr, int key);
// void test(Tnode* root);

//eval
int evaluate(FILE* fp);
void checkbst(Tnode* curr, int* bstcheck);
void checkbal(Tnode* curr, int* balcheck);
Tnode* readtree(FILE* fp);
int calcheight(Tnode* curr);
