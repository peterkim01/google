#include <stdlib.h>
#include <stdio.h>

typedef struct Node {
   //int info?
   char label;
   int numlabel;
   int x;
   int y;
   int w;
   int h;
   int xcor;
   int ycor;
   
   struct Node *left;
   struct Node *right;
} Node;

Node* filetotree(FILE* f);
void postorder(Node* head, FILE *fw);
void freenode(Node * head);
void dimension(Node* curr);
int findmax(int a, int b);
void dim_po(Node* curr, FILE *fdim);
void packing(Node* curr, int xcor, int ycor);
void printleaf(Node* curr, FILE* pck);

// Node *List_Load_From_File(char *filename);

// int List_Save_To_File(char *filename, Node *list);

// Node *List_Shellsort(Node *list, long *n_comp);



