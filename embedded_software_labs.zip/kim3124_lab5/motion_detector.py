######################################
class MPU:
    # Static MPU memory addresses
    ACC_X = 0x3B
    ACC_Y = 0x3D
    ACC_Z = 0x3F
    TEMP = 0x41
    GYRO_X = 0x43
    GYRO_Y = 0x45
    GYRO_Z = 0x47

    def acceleration(self):
        # self.i2c.start()
        acc_x = self.i2c.readfrom_mem(self.addr, MPU.ACC_X, 2)
        acc_y = self.i2c.readfrom_mem(self.addr, MPU.ACC_Y, 2)
        acc_z = self.i2c.readfrom_mem(self.addr, MPU.ACC_Z, 2)
        # self.i2c.stop()

        # Accelerometer by default is set to 2g sensitivity setting
        # 1g = 9.81 m/s^2 = 16384 according to mpu datasheet
        acc_x = self.__bytes_to_int(acc_x) / 16384 * 9.81
        acc_y = self.__bytes_to_int(acc_y) / 16384 * 9.81
        acc_z = self.__bytes_to_int(acc_z) / 16384 * 9.81

        return acc_x, acc_y, acc_z

    def temperature(self):
        # self.i2c.start()
        temp = self.i2c.readfrom_mem(self.addr, self.TEMP, 2)
        # self.i2c.stop()

        temp = self.__bytes_to_int(temp)
        return self.__celsius_to_fahrenheit(temp / 340 + 36.53)
    
    def gyro(self):
        return self.pitch, self.roll, self.yaw

    def __init_gyro(self):
        # MPU must be stationary
        gyro_offsets = self.__read_gyro()
        self.pitch_offset = gyro_offsets[1]
        self.roll_offset = gyro_offsets[0]
        self.yaw_offset = gyro_offsets[2]

    def __read_gyro(self):
        # self.i2c.start()
        gyro_x = self.i2c.readfrom_mem(self.addr, MPU.GYRO_X, 2)
        gyro_y = self.i2c.readfrom_mem(self.addr, MPU.GYRO_Y, 2)
        gyro_z = self.i2c.readfrom_mem(self.addr, MPU.GYRO_Z, 2)
        # self.i2c.stop()

        # Gyro by default is set to 250 deg/sec sensitivity
        # Gyro register values return angular velocity
        # We must first scale and integrate these angular velocities over time before updating current pitch/roll/yaw
        # This method will be called every 100ms...
        gyro_x = self.__bytes_to_int(gyro_x) / 131 * 0.1
        gyro_y = self.__bytes_to_int(gyro_y) / 131 * 0.1
        gyro_z = self.__bytes_to_int(gyro_z) / 131 * 0.1

        return gyro_x, gyro_y, gyro_z
    
    def __update_gyro(self, timer):
        gyro_val = self.__read_gyro()
        self.pitch += gyro_val[1] - self.pitch_offset
        self.roll += gyro_val[0] - self.roll_offset
        self.yaw += gyro_val[2] - self.yaw_offset

    @staticmethod
    def __celsius_to_fahrenheit(temp):
        return temp * 9 / 5 + 32

    @staticmethod
    def __bytes_to_int(data):
        # Int range of any register: [-32768, +32767]
        # Must determine signing of int
        if not data[0] & 0x80:
            return data[0] << 8 | data[1]
        return -(((data[0] ^ 0xFF) << 8) | (data[1] ^ 0xFF) + 1)

    def __init__(self, i2c):
        # Init MPU
        self.i2c = i2c
        self.addr = i2c.scan()[0]
        # self.i2c.start()
        self.i2c.writeto(0x68, bytearray([107,0]))
        # self.i2c.stop()
        print('Initialized MPU6050.')

    # Gyro values will be updated every 100ms after creation of MPU object
        self.pitch = 0
        self.roll = 0
        self.yaw = 0
        self.pitch_offset = 0
        self.roll_offset = 0
        self.yaw_offset = 0
        self.__init_gyro()
        gyro_timer = Timer(3)
        gyro_timer.init(mode=Timer.PERIODIC, callback=self.__update_gyro, period=100)
        
######################################

from machine import I2C, Pin, Timer
import time
import network
import esp32
import socket
import neopixel as n

write_api = 'HZI2JH2RX81ABRJ1'
read_api = '2HX1TKJF6O7FGAR8'
channel_id = '2777142'
sensor_status = 0
np = n.NeoPixel(Pin(0), 1) 
red_led = Pin(13, Pin.OUT)

i2c = I2C(1, scl=Pin(14), sda=Pin(22))
mpu = MPU(i2c)

offset_x = 0.0
offset_y = 0.0
offset_z = 0.0

def setColor(r,g,b):        # set neopixel color
    np[0] = (r,g,b)
    np.write()
    
def calibrate_accelerometer(mpu):
    global offset_x, offset_y, offset_z
    print("Calibrating accelerometer...")
    time.sleep(2) # stabilize sensor

    sum_x, sum_y, sum_z = 0, 0, 0

    num_samples = 50
    for _ in range(num_samples):
        acc_x, acc_y, acc_z = mpu.acceleration()
        sum_x += acc_x
        sum_y += acc_y
        sum_z += acc_z
        time.sleep(0.03)

    avg_x = sum_x / num_samples
    avg_y = sum_y / num_samples
    avg_z = sum_z / num_samples

    offset_x = avg_x
    offset_y = avg_y
    offset_z = avg_z - 9.81 

    print(f"Calibration Complete.")
    print(f"Offsets -> X: {offset_x:.2f}, Y: {offset_y:.2f}, Z: {offset_z:.2f}")
    
def get_calibrated_acceleration(mpu):
    acc_x, acc_y, acc_z = mpu.acceleration()
    cal_x = acc_x - offset_x
    cal_y = acc_y - offset_y
    cal_z = acc_z - offset_z
    
    return cal_x, cal_y, cal_z

def connect_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    ssid = 'phasorphone'
    pwd = '12345678'
    
    if not wlan.isconnected():
        print('connecting to network...')
        wlan.connect(ssid, pwd)
        while not wlan.isconnected():
            pass
    print(f"Connected to {ssid}")
    print('IP Address:', wlan.ifconfig()[0])

def receive_sensor_status(tim):
    global sensor_status
    try:
        url = f"https://api.thingspeak.com/channels/{channel_id}/fields/1/last?api_key={read_api}"
        _, _, host, path = url.split('/', 3)
        addr = socket.getaddrinfo(host, 80)[0][-1]
        s = socket.socket()
        s.connect(addr)
        s.send(bytes(f"GET /{path} HTTP/1.1\r\nHost: {host}\r\n\r\n", 'utf8'))
        response = s.recv(1024)
        s.close()
        
        sensor_status = int(response.decode().split('\r\n\r\n')[1])
        print(f"Sensor status: {'On' if sensor_status else 'Off'}")
        
        if sensor_status:       # sensor on
            setColor(0,255,0)
        else:                   # sensor off
            setColor(0,0,0)
            
    except Exception as e:
        print(f"Failed to read data from ThingSpeak: {e}")

def send_sensor_status(sensor_status):
    url = f"https://api.thingspeak.com/update?api_key={write_api}&field1={sensor_status}"
    
    try:
        _, _, host, path = url.split('/', 3)
        addr = socket.getaddrinfo(host, 80)[0][-1]
        s = socket.socket()
        s.connect(addr)
        s.send(bytes(f"GET /{path} HTTP/1.1\r\nHost: {host}\r\n\r\n", 'utf8'))
        response = s.recv(1024)
        s.close()
        
        print(f"Sensor status {"On" if sensor_status else "Off"}")
        
    except Exception as e:
        print(f"Failed to send sensor status: {e}")

def check_motion(mpu, cal_z, start_time):
    _, _, new_z = mpu.acceleration()
    
    if new_z > cal_z or -1*new_z > cal_z:       # motion detected
        red_led.value(1)
        
        # send notifications to IFTTT
        url = "https://maker.ifttt.com/trigger/motion_detected/with/key/guaDG4408OM2rW1KahDI9qKAbBzAbS1m3m9qHXLg5Os"
        
        if time.time() - start_time < 60:
            try:
                print("Motion detected, sending notification to ITFFF...")
                _, _, host, path = url.split('/', 3)
                addr = socket.getaddrinfo(host, 80)[0][-1]
                s = socket.socket()
                s.connect(addr)
                s.send(bytes(f"GET /{path} HTTP/1.1\r\nHost: {host}\r\n\r\n", 'utf8'))
                response = s.recv(1024)
                s.close()
                print("IFTTT notification sent successfully.")
                
            except Exception as e:
                print("Failed to send IFTTT notification")
        else:
            print("Motion detected, 1 minute passed, no notification sent.")
    else:
        red_led.value(0)
        # print("No motion detected.")
        
        
def main():
    global sensor_status
    calibrate_accelerometer(mpu)
    cal_x, cal_y, cal_z = get_calibrated_acceleration(mpu)
    print(f"Sensor Acceleration -> X: {cal_x:.2f} m/s^2, Y: {cal_y:.2f} m/s^2, Z: {cal_z:.2f}")

    connect_wifi()

    sensor_status = 0   # 0: OFF 1: ON
    tim1 = Timer(0)        # hardware timer 1
    tim1.init(period=30000, mode=Timer.PERIODIC, callback=receive_sensor_status)
    
    try:
        while True:
            if sensor_status:
                if status_change:
                    start_time = time.time()
                
                check_motion(mpu, cal_z, start_time)
                status_change = False
                
            else:
                status_change = True
            
    except KeyboardInterrupt:
        print("Prgram terminated...")

if __name__ == '__main__':
    main()
