Potentiometer: connected to A4 (PIN 36), 3.3V, ground 
LED: connected to A1 (PIN 25) in series with a resistor, ground


https://youtu.be/WFg-u5I_is4

