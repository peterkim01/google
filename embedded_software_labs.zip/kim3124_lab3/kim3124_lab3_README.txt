Touch Pad: Connected to A5 (Pin 4)
External Switch: Connected to A4 (Pin 36). External Switch also connected to 3.3V and pull-down resistor

Demo Video: https://youtu.be/1gnXCH_fzVw
