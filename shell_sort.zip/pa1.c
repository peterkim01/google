#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "sequence.h"
#include "shell_array.h"
#include "shell_list.h"

void freelist(Node* head);
void printnode(Node* curr);

int main(int argc, char* argv[]){
    // gcc -g -std=c99 -Wall -Wshadow -Wvla -pedantic sequence.c shell_array.c shell_list.c pa1.c -o pa1
    // valgrind ./pa1 -l ./examples/15.b ./output.b

    int arr_size; 
    long* bintoArr;
    long n_comp = 0;
    Node* head = NULL; 

   if(argc != 4){
    fprintf(stderr, "Insufficient argv\n");
    return EXIT_FAILURE;
   }

    if(!(strcmp(argv[1], "-a"))){
        bintoArr = Array_Load_From_File(argv[2], &arr_size);
        Array_Shellsort(bintoArr, arr_size, &n_comp);
        arr_size = Array_Save_To_File(argv[3], bintoArr, arr_size); //check if this is correct
        printf("%ld\n", n_comp);

        // for(int i=0; i<arr_size; i++){
        //     printf("%ld\n", bintoArr[i]);
        // }
        // long* ans = Array_Load_From_File("./examples/15sa.b", &arr_size); //testing
        // for(int i = 0; i<arr_size;i++){
        //     printf("%ld\n", ans[i]);
        // }

        free(bintoArr);
        return EXIT_SUCCESS;
    }
    else if(!(strcmp(argv[1], "-l"))){
        head = List_Load_From_File(argv[2]);
        head = List_Shellsort(head, &n_comp);
        int listElement = List_Save_To_File(argv[3], head);
        printf("%ld\n", n_comp);

        //test//
        // printf("%d\n", listElement);
        // printf("\n\n");
        // Node* newhead = List_Load_From_File(argv[3]);
        // printnode(newhead);

        freelist(head);
        return EXIT_SUCCESS;
    }
    else{
        fprintf(stderr, "Invalid option\n");
        return EXIT_FAILURE;
    }
}

///////HELP FUNCTIONS//////////
void freelist(Node* head){
    Node* next; 

    while (head != NULL){
        next = head->next;
        free(head);
        head = next;
    }
}

void printnode(Node* curr){
    while(curr != NULL){
        printf("%ld\n", curr->value);
        curr = curr->next;
    }
}
