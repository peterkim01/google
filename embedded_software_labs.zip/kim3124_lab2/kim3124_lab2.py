import machine
import time
from machine import Pin


year = int(input("Year? "))
month = int(input("Month? "))
day = int(input("Day? "))
weekday = int(input("Weekday? "))
hour = int(input("Hour? "))
minute = int(input("Minute? "))

rtc = machine.RTC()
rtc.datetime((year, month, day, weekday, hour, minute, 0, 0))

def read_datetime(timer):
    current_time = rtc.datetime()
    print("---------------------------")
    print(f"RTC Date: {current_time[2]:02d}/{current_time[1]:02d}/{current_time[0]:04d}")
    print(f"RTC Time: {current_time[4]:02d}:{current_time[5]:02d}:{current_time[6]:02d}") 
    print("---------------------------")

timer = machine.Timer(0)
timer.init(period=30000, mode=machine.Timer.PERIODIC, callback=read_datetime)

adc = machine.ADC(machine.Pin(36))
adc.atten(machine.ADC.ATTN_11DB)  #do i need this?

pot_value = 0

def read_pot(timer):
    global pot_value
    pot_value = adc.read()  

pot_timer = machine.Timer(1)
pot_timer.init(period=100, mode=machine.Timer.PERIODIC, callback=read_pot)

led_pin = machine.Pin(25, machine.Pin.OUT)
pwm = machine.PWM(led_pin)
pwm.freq(10)  
pwm.duty(512)


button = machine.Pin(38, Pin.IN, Pin.PULL_UP)
debounce_timer = machine.Timer(2)
debounce_time = 50
switch_pressed = False
cnt = 0

def debounce_callback(timer):
    global switch_pressed
    if button.value() == 0:
        switch_pressed = True
    else:
        switch_pressed = False

def isr(pin):
    debounce_timer.deinit() 
    debounce_timer.init(period=debounce_time, mode=machine.Timer.ONE_SHOT, callback=debounce_callback)

button.irq(trigger=machine.Pin.IRQ_FALLING, handler=isr)

control_frequency = True	 #if false, dutycycle mode

while True:
    if switch_pressed:	    	#mode control
        cnt += 1
        if cnt % 2 == 1:
            control_frequency = True
        else:
            control_frequency = False
        switch_pressed = False

        if control_frequency:
            print("Frquency Control Mode")
        else:
            print("Duty Cycle Control Mode")
    
    if control_frequency:		 #frequency control mode
        new_freq = int((pot_value/4095) * 101)  #0-100hz
        new_freq = max(1, new_freq)
        pwm.freq(new_freq)
        print(f"Frequency: {new_freq} Hz")
    elif not control_frequency:		 #duty cycle control mode
        new_duty = int((pot_value / 4095) * 1023)   #0-1023
        pwm.duty(new_duty)
        print(f"Duty Cycle: {new_duty}/1023")

    time.sleep(0.5)
    