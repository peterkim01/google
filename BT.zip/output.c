#include "output.h"

#include <stdlib.h>
#include <stdio.h>

Node* filetotree(FILE* f){
    int numlabel;
    int x, y;
    char label;
    Node* curr = NULL;
    if(!feof(f)){  
        curr = (struct Node *)malloc(sizeof(Node));  

        if(fscanf(f, "%d(%d,%d)\n",&numlabel, &x, &y) == 3){
            curr->numlabel = numlabel;
            curr->x = x;
            curr->y = y;
            curr->label = '\0';
            curr->left = NULL;
            curr->right = NULL;
            
            return curr;
        }else{
            fscanf(f, "%c\n",&label);
            curr->label = label;  

            curr->left = filetotree(f);
            curr->right = filetotree(f);
            return curr;
        }
    }
    return curr;
}

/////////////////output 1///////////////////
void postorder(Node* head, FILE* fw){
    if(head == NULL) return;

    postorder(head -> left, fw);
    postorder(head -> right, fw);
    if(head->label == 'V' || head->label == 'H'){
        fprintf(fw, "%c\n", head->label);
    }
    else{
        fprintf(fw, "%d(%d,%d)\n", head->numlabel, head->x, head->y);
    }
}
///////////////end of output 1//////////////

///////////////output 2/////////////////////
void dimension(Node* curr){
    if(curr == NULL) return;

    dimension(curr->right);
    dimension(curr->left);

    if(curr->label == 'H'){
        curr-> w = findmax(curr->left->w, curr->right->w);
        curr->h = curr->left->h + curr->right->h;

    }else if(curr->label =='V'){
        curr->h = findmax(curr->left->h, curr->right->h);
        curr->w = curr->left->w + curr->right->w;
    }
    else{ //leaf node
        curr->w = curr->x;
        curr->h = curr->y;
    }
}

void dim_po(Node* curr, FILE* fdim){
    if(curr == NULL) return;

    dim_po(curr -> left, fdim);
    dim_po(curr -> right, fdim);
    
    if(curr->label == 'V' || curr->label == 'H'){
        fprintf(fdim, "%c(%d,%d)\n", curr->label, curr->w, curr->h);
    }
    else{
        fprintf(fdim, "%d(%d,%d)\n", curr->numlabel, curr->w, curr->h);
    }
}
///////////////end of output 2//////////////

///////////////output 3/////////////////////
void packing(Node* curr, int xcor, int ycor){
    if(curr == NULL) return;
    
    if(curr->label == 'H'){
        packing(curr->left, xcor, ycor + curr->right->h);
        packing(curr->right, xcor, ycor);
    }
    else if(curr->label == 'V'){
        packing(curr->left, xcor, ycor);
        packing(curr->right, xcor + curr->left->w, ycor);
    }

    if(curr->label == 'H'){
        curr->right->xcor = xcor;
        curr->right->ycor = ycor;

        curr->left->xcor = xcor;
        ycor = ycor + curr->right->h;
        curr->left->ycor = ycor;
        
    }
    else if(curr->label == 'V'){
        curr->left->xcor = xcor;
        curr->left->ycor = ycor;
        
        xcor = xcor + curr->left->w;
        curr->right->xcor = xcor;
        curr->right->ycor = ycor;
    }else{
        curr->xcor = xcor;
        curr->ycor = ycor;
    }
}

void printleaf(Node* curr, FILE* fpck){
    if(curr == NULL) return;

    printleaf(curr->left, fpck);
    printleaf(curr->right, fpck);

    if(curr->left == NULL && curr->right == NULL){
        fprintf(fpck, "%d((%d,%d)(%d,%d))\n", curr->numlabel, curr->w, curr->h, curr->xcor, curr->ycor);
    }
}
///////////////end of output 3//////////////

///////////////HELP FUNCTIONS///////////////
void freenode(Node* head)
{
	if(head == NULL) return;

	freenode(head -> left);
	freenode(head -> right);

	free(head);
}

int findmax(int a, int b){
    if (a>b){
        return a;
    }
    return b;
}
