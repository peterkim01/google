from machine import TouchPad, Pin, Timer
import esp32
import network
import socket
import time
api_key = 'UGUPL93SC2KFASBR'
channel_id = '2734246'

call_cnt = 0

def connect_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    ssid = 'phasorphone'
    pwd = '12345678'
    
    if not wlan.isconnected():
        print('connecting to network...')
        wlan.connect(ssid, pwd)
        while not wlan.isconnected():
            pass
    print(f"Connected to {ssid}")
    print('IP Address:', wlan.ifconfig()[0])

def collect_data(timer):
    global call_cnt
    call_cnt += 1
    temp = esp32.raw_temperature()
    hall = esp32.hall_sensor()
    print("--------------------------")
    print(f"Temperature: {temp}")
    print("Hall: ", hall)
    
    
    url = f'http://api.thingspeak.com/update?api_key={api_key}&field1={temp}&field2={hall}'
    
    _, _, host, path = url.split('/', 3)
    host = "api.thingspeak.com"
    addr = socket.getaddrinfo(host, 80)[0][-1]
    
    s = socket.socket()
    s.connect(addr)
    s.send(bytes(f'GET /{path} HTTP/1.0\r\nHost: {host}\r\nConnection: close\r\n\r\n', 'utf8'))
    
    while True:
        data = s.recv(100)
        if len(data) < 1:
            break
        print(str(data, 'utf8'), end='')
    
    s.close()
  

def main():
    connect_wifi()
    
    timer = Timer(0)        #hardware timer 1
    timer.init(period=30000, mode=Timer.PERIODIC, callback=collect_data)
    
    while True:
        if call_cnt == 10:
            timer.deinit()
            break
   
if __name__ == '__main__':
    main()
