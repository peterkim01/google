#include <stdio.h>
#include <stdlib.h>

typedef struct Pqueue{
    // int idx; //index in min-heap
    int d; //distance required to reach this vertex
    int vertex_idx; //index(label) of vertex
    int pred;
} Pqueue;

typedef struct Vertex{
    struct Nnode *nnode;

    int w;  //is board latched?
    float xcor;
    float ycor;
    int idx; //heap index
    int check_first; //check if connected to source
} Vertex;

typedef struct Nnode{
    struct Nnode *nnode;

    int w; //distance from vertex to adj node
    int idx;   //label
} Nnode;

Vertex* build_graph(char* filename, int* vcnt);
Pqueue* buildPQ(Vertex* graph, int vcnt);
Pqueue* dijkstra(Vertex* graph, int s, int vcnt);
Pqueue* extractmin(Pqueue* pq, int last_idx, int s, Vertex* graph);
void swap(Pqueue* pq, int x, int y);
void downward_heapify(Pqueue* pq, int i, int n, Vertex* graph);
void upward_heapify(Pqueue* pq, int n, int last_idx, Vertex* graph);
// int find_vertex(Pqueue* pq, int v, int last_idx);
void freegraph(Vertex* graph, int vcnt);
Pqueue findtemp(Pqueue* pq, int vcnt, int x);
