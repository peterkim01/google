#include <stdio.h>
#include <stdlib.h>

#include "sequence.h"
#include "shell_array.h"
#include "shell_list.h"

Node* findnode(Node* curr, long n);

Node *List_Load_From_File(char *filename){
    FILE* fp = fopen(filename, "rb");
    Node *head = NULL;
    Node *curr = NULL;
    Node *newnode;
    long newvalue;

    if(fp == NULL){
        return head;
    }

    while(fread(&newvalue, sizeof(long), 1, fp)){
        newnode = malloc(sizeof(Node));  
        if(head == NULL){
            newnode->value = newvalue;
            newnode->next = NULL;
            head = curr = newnode;
        }else{
            newnode->value = newvalue;
            newnode->next = NULL;
            curr->next = newnode;
            curr = newnode;
        }
    }

    fclose(fp);
    return head;
}

int List_Save_To_File(char *filename, Node *list){
    FILE *fw = fopen(filename, "wb");
    int size = 0;

    while(list != NULL){
        fwrite(&(list->value), (sizeof(long)), 1, fw);
        list = list->next;
        size++;
    }

    fclose(fw);
    return(size);
}

Node *List_Shellsort(Node *list, long *n_comp){
    int listsize = 0;
    int seq_size;
    Node* nodeX, *nodeY, *pnodeX, *pnodeY, *temp;
    Node* curr = list;
    
    while(curr != NULL){ //find total list size
        curr = curr->next;
        listsize++;
    }
    // curr = list;
    long* seq = Generate_2p3q_Seq(listsize, &seq_size); //generate 2p3q sequence

    for(int k = seq_size-1; k >= 0; k--){ //for each value of seq
        int sorted = 0; //not sorted 0, sorted if 1
        int lastexchange = listsize;
        long temp_k = seq[k];
        nodeX = list;
        nodeY = list;
        pnodeX = NULL;
        
        while(temp_k){
            pnodeY = nodeY;
            nodeY = nodeY->next;
            temp_k--;
        }
        // printf("pnodeY val: %ld\n", pnodeY->value);
        
        while(!sorted){
            sorted = 1;
            int last_element = lastexchange - 1;
            
            for(int i = seq[k]; i <= last_element; i++){
                // printf("nodeX val: %ld, k val: %ld\n", nodeX->value, seq[k]);
                *n_comp = *n_comp + 1;
                int swap = 0;
                if((nodeY != NULL) && (nodeX->value > nodeY->value)){ //seg fault
                    swap = 1;

                    // swap two nodes
                    if(pnodeY != NULL){
                        pnodeY->next = nodeX;
                    }
                    else{   
                        list = nodeX; //change head
                    }
                    if(pnodeX != NULL){
                        pnodeX->next = nodeY;
                    }
                    else{ 
                        list = nodeY; //change head
                    }
                    temp = nodeY->next;
                    nodeY->next = nodeX->next;
                    nodeX->next = temp;

                    lastexchange = i;
                    sorted = 0;
                }
                if(swap){
                    pnodeX = nodeY;
                    pnodeY = nodeX;
                    nodeX = pnodeX->next;
                    nodeY = pnodeY->next;
                    
                }else if(nodeY != NULL){
                    pnodeX = nodeX;
                    nodeX = nodeX->next;
                    pnodeY = nodeY;
                    nodeY = nodeY->next;
                }
            }
        }
    }

    free(seq);
    return list;
}
