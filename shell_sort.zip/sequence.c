#include <stdio.h>
#include <stdlib.h>
#include "sequence.h"


//declare functions
int power(int pplusq);
void insertsort(long *seq, int cnt);
void makeSeq(long *seq, int n, int curr, int* seq_size);
int checkdup(long *seq, int curr, int size);

long *Generate_2p3q_Seq(int n, int *seq_size){
    //16 -> 1,2,3,4,6,9,12

    int pplusq = 1;
    long* seq;
    int curr = 1;
    *seq_size = 0;

    if(n>1){
        while(n > power(pplusq)){
            pplusq++;
        }
    }   //found p+q
    
    if(curr == 1 && n > 1){
        seq = (long *)malloc(sizeof(long) * ((pplusq+2) * (pplusq+1)));  //sizeof(long) * length of seq array
        seq[*seq_size] = curr;
    }else if(n < 2){
        *seq_size = 0;
        seq = (long *)malloc(sizeof(long) * *seq_size);
        return seq;
    }

    makeSeq(seq, n, curr, seq_size);
    *seq_size = *seq_size + 1;
    insertsort(seq, *seq_size); //sort the list

    return seq;
}

void makeSeq(long *seq, int n, int curr, int* seq_size){ //recursively make sequence
    if (n < 2){
        *seq_size = 0;
        seq = NULL;
    }
    else{
        if(curr * 2 < n){
            if(curr * 3 < n){
                if(!checkdup(seq, curr*3, *seq_size)){
                    *seq_size = *seq_size + 1;
                    seq[*seq_size] = curr * 3;
                    makeSeq(seq, n, curr * 3, seq_size);
                }    
            }
            if(!checkdup(seq, curr*2, *seq_size)){
                *seq_size = *seq_size + 1;
                seq[*seq_size] = curr * 2;
                makeSeq(seq, n, curr * 2, seq_size);
            }
        }       
    } 
}

int checkdup(long *seq, int curr, int size){ //check duplicate
    for(int i = 0; i < size; i++){
        if(seq[i] == curr){
            return 1;
        }
    }
    return 0;
}

int power(int pplusq){
    //returns 3 ** pplusq
    int threepowcnt = 1;
    while(pplusq > 0){
        threepowcnt = threepowcnt * 3;   
        pplusq--;
    }
    return(threepowcnt);
}

void insertsort(long *seq, int cnt){ 
    int j, i;

    for(j = 0; j < cnt; j++){
        long temp = seq[j];
        for(i = j; i > 0; i--){
            if(seq[i-1] > temp){
                seq[i] = seq[i-1];
            }else{
                break;
            }
        }
        seq[i] = temp;
    }
}
