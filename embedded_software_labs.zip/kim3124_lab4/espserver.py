import network
import esp32
import socket
from machine import Pin

# Global variables
temp = 0 # measure temperature sensor data
hall = 0 # measure hall sensor data
red_led_state = 'OFF' # string, check state of red led, ON or OFF

def web_page():
    """Function to build the HTML webpage which should be displayed
    in client (web browser on PC or phone) when the client sends a request
    the ESP32 server.
    
    The server should send necessary header information to the client
    (YOU HAVE TO FIND OUT WHAT HEADER YOUR SERVER NEEDS TO SEND)
    and then only send the HTML webpage to the client.
    
    Global variables:
    temp, hall, red_led_state
    """
    
    html_webpage = """<!DOCTYPE HTML><html>
    <head>
    <title>ESP32 Web Server</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <style>
    html {
     font-family: Arial;
     display: inline-block;
     margin: 0px auto;
     text-align: center;
    }
    h1 { font-size: 3.0rem; }
    p { font-size: 3.0rem; }
    .units { font-size: 1.5rem; }
    .sensor-labels{
      font-size: 1.5rem;
      vertical-align:middle;
      padding-bottom: 15px;
    }
    .button {
        display: inline-block; background-color: #e7bd3b; border: none; 
        border-radius: 4px; color: white; padding: 16px 40px; text-decoration: none;
        font-size: 30px; margin: 2px; cursor: pointer;
    }
    .button2 {
        background-color: #4286f4;
    }
    </style>
    </head>
    <body>
    <h1>ESP32 WEB Server</h1>
    <p>
    <i class="fas fa-thermometer-half" style="color:#059e8a;"></i> 
    <span class="sensor-labels">Temperature</span> 
    <span>"""+str(temp)+"""</span>
    <sup class="units">&deg;F</sup>
    </p>
    <p>
    <i class="fas fa-bolt" style="color:#00add6;"></i>
    <span class="sensor-labels">Hall</span>
    <span>"""+str(hall)+"""</span>
    <sup class="units">V</sup>
    </p>
    <p>
    RED LED Current State: <strong>""" + red_led_state + """</strong>
    </p>
    <p>
    <a href="/?red_led=on"><button class="button">RED ON</button></a>
    </p>
    <p>
    <a href="/?red_led=off"><button class="button button2">RED OFF</button></a>
    </p>
    </body>
    </html>"""
    return html_webpage

def collect_data():
    
    return esp32.raw_temperature(), esp32.hall_sensor()
    
def connect_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    ssid = 'phasorphone'
    pwd = '12345678'
    
    if not wlan.isconnected():
        print('connecting to network...')
        wlan.connect(ssid, pwd)
        while not wlan.isconnected():
            pass
    print(f"Connected to {ssid}")
    print('IP Address:', wlan.ifconfig()[0])

    
def main():
    global hall, temp, red_led_state
    
    connect_wifi()   
    led_board = Pin(13, Pin.OUT)
    
    addr = socket.getaddrinfo('172.20.10.2', 80)[0][-1]
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(addr) 
    server_socket.listen(10)
    print(addr)
    temp, hall = collect_data()
    webpage = web_page()
    
    while True:
        
        client_socket, addr = server_socket.accept()
        print("Connected from ", addr)
        client_request = str(client_socket.recv(1024))
        
        if '/?red_led=on' in client_request:
            led_board.value(1)
            red_led_state = 'ON'
        elif '/?red_led=off' in client_request:
            led_board.value(0)
            red_led_state = 'OFF'
        
        temp, hall = collect_data()
        print(type(temp), type(hall))
        response = web_page()   # update
        
        client_socket.send('HTTP/1.1 200 OK\n')
        client_socket.send('Content-Type: text/html\n')
        client_socket.send('Connection: close\n\n')
        client_socket.sendall(response)
        
        client_socket.close()
               
if __name__ == '__main__':
    main()