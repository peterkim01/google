#include "pa5.h"
#include <limits.h>

int main(int argc, char *argv[]){
    //  gcc -g -std=c99 -pedantic -Wvla -Wall -Wshadow *.c -o pa5 
    //  gcc -g -std=c99 -pedantic -Wvla -Wall -Wshadow -o3 *.c -o pa5
    //  valgrind -s --leak-check=full --show-leak-kinds=all ./pa5 ./examples/river.in0 ./output0.out1 ./output0.out2

    if(argc != 4){
        fprintf(stderr, "\nInvalid number of input or ouput files");
        return EXIT_FAILURE;
    }
    int vcnt = 0; //vertex count

    Vertex* graph = build_graph(argv[1], &vcnt);
    
    // test build graph, adj list
    // for(int i = 0; i< vcnt; i++){
    //     printf("x: %f y: %f w: %d, idx: %d\n", graph[i].xcor, graph[i].ycor, graph[i].w, graph[i].idx);
    //     Nnode* curr = graph[i].nnode;
    //     while(curr != NULL){
    //         printf("%d ", curr->idx);
    //         printf("\n");
    //         curr = curr->nnode;
    //     }
    // }
    // printf("vcnt: %d\n", vcnt);
    
    Pqueue* pq = dijkstra(graph, 0, vcnt);

    // for(int i = 0; i < vcnt; i++){
    //     printf("vertex: %d total rotations: %d\n", pq[i].vertex_idx, pq[i].d);
    // }
    
    //print output 1
    FILE* fw = fopen(argv[2], "w");
    if(fw == NULL){
        fprintf(stderr, "Incorrect input file format\n");
        return EXIT_FAILURE;
    }
    Pqueue temp = findtemp(pq, vcnt, vcnt-1);
    int* order = malloc(sizeof(int) * vcnt);
    int k;
    for(k = 0; k <= vcnt; k++){
        if(temp.pred != SHRT_MIN){
            order[k] = temp.vertex_idx;
        }else{
            order[k] = temp.vertex_idx;
            break;
        }
        temp = findtemp(pq, vcnt, temp.pred);
    }

    for (int i = k; i >= 0; i--) {
        if(i == k){         //when source
            // printf("1order i: %d\n",order[i]);
            fprintf(fw, "(%d,%d)(%d,%d)\n", (int)(graph[order[i-1]].ycor+0.5), -1, (int)(graph[order[i-1]].ycor+0.5),(int)graph[order[i-1]].xcor); //fix
        }else if(i == 0){   //when destination
            // printf("2order i: %d\n",order[i]);
            fprintf(fw, "(%d,%d)(%d,%d)\n", (int)(graph[order[i+1]].ycor+0.5), (int)(graph[order[i+1]].xcor), (int)(graph[order[i+1]].ycor+0.5),(int)(graph[order[i+1]].xcor+1)); //fix
        }else if(graph[order[i]].xcor - (int)graph[order[i]].xcor == 0){ //when board is vertical
            // printf("3order i: %d\n",order[i]);
            fprintf(fw, "(%d,%d)(%d,%d)\n", (int)(graph[order[i]].ycor-0.5),(int)graph[order[i]].xcor, (int)(graph[order[i]].ycor+0.5),(int)graph[order[i]].xcor);
        }else if(graph[order[i]].xcor - (int)graph[order[i]].xcor != 0){ //when board is horizontal
            // printf("4order i: %d\n",order[i]);
            fprintf(fw, "(%d,%d)(%d,%d)\n", (int)(graph[order[i]].ycor),(int)(graph[order[i]].xcor-0.5), (int)(graph[order[i]].ycor),(int)(graph[order[i]].xcor+0.5));
        }  
    }

    //print output 2


    //free memory
    fclose(fw);
    freegraph(graph, vcnt);
    free(order);
    free(pq);
}

Pqueue findtemp(Pqueue* pq, int vcnt, int x){
    Pqueue temp;
    for(int i = 0; i < vcnt; i++){
        if(pq[i].vertex_idx == x){
            temp = pq[i];
            break;
        }
    }
    return temp;
}

void freegraph(Vertex* graph, int vcnt) {
    // free each Vertex in the array
    for (int i = 0; i < vcnt; i++) {
        // free all the Nnodes associated with the Vertex
        Nnode* n = graph[i].nnode;
        while (n != NULL) {
            Nnode* temp = n;
            n = n->nnode;
            free(temp);
        }
    }
    // free the array itself
    free(graph);
}        
