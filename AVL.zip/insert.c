#include "hbt.h"
#include "pa4.h"

Tnode* buildtree(FILE* fp){
    Tnode * head = NULL;
    int key;

    while(fread(&key, sizeof(int), 1, fp)){
        // int tempbal = 0;
        char id = readid(fp);
        if(id){
            // printf("%d, %c\n", key, id);
            if(id == 'i'){
                searchandinsert(&head, key);
            }else if(id == 'd'){
                head = searchandbal(head, NULL, key);
            }else{
                return NULL;
            }
        }
    }   
    return head;
}

Tnode *searchandinsert(Tnode **root, int key){
    Tnode* pcurr = NULL;
    Tnode* curr = *root;
    Tnode* ya = curr;
    Tnode* pya = pcurr;
    Tnode* q = NULL;
    Tnode* child = NULL;
    
    while(curr != NULL){
        if(key <= curr->key){
            q = curr->left;
        }else{
            q = curr->right;
        }
        if(q != NULL && q->balance != 0){
            pya= curr;
            ya = q;
        }
        pcurr = curr;
        curr = q;
    } 
    q = malloc(sizeof(Tnode)); //make node
    q->key = key;
    q->left = NULL;
    q->right = NULL;
    q->balance = 0;

    if(pcurr == NULL){
        *root = q;
    }else{
        if(key <= pcurr->key){
            pcurr->left = q;
        }else{
            pcurr->right = q;
        }
        curr = ya;
        while(curr != q){
            if(key <= curr->key){
                curr->balance = curr->balance + 1;
                curr = curr->left;
            }else{
                curr->balance = curr->balance -1;
                curr = curr->right;
            }
        }
        if((ya->balance < 2) && (ya->balance > -2)){
            return q;
        }
        
        if(key <= ya->key){
            child = ya->left;
        }else{
            child = ya->right;
        }
        
        //rotation if needed
        if((ya->balance == 2) && (child->balance == 1)){ //case 1
            curr = clock_rotation(ya);
            ya->balance = 0;
            child->balance = 0;
        }

        if((ya->balance == -2) && (child->balance == -1)){ //case 2
            curr = anticlock_rotation(ya);
            ya->balance = 0;
            child->balance = 0;
        }

        if((ya->balance == 2) && (child->balance == -1)){ //case 3 
            ya->left = anticlock_rotation(child);
            curr = clock_rotation(ya);
            if(curr->balance == 0){
                ya->balance = 0;
                child->balance = 0;
            }else{
                if(curr->balance == 1){
                    ya->balance = -1;
                    child->balance = 0;
                }else{
                    ya->balance = 0;
                    child->balance = 1;
                }
                curr->balance=0;
            }
        }

        if((ya->balance == -2) && (child->balance == 1)){ //case 4
            ya->right = clock_rotation(child);
            curr = anticlock_rotation(ya);
            if(curr->balance == 0){
                ya->balance = 0;
                child->balance = 0;
            }else{
                if(curr->balance == -1){
                    ya->balance = 1;
                    child->balance = 0;
                }else{
                    ya->balance = 0;
                    child->balance = -1;
                }
                curr->balance=0;
            }
        }

        if(pya == NULL){
            *root = curr;
        }else{
            if(key <= pya->key){
                pya->left = curr;
            }else{
                pya->right = curr;
            }
        }
    }

    //update the balance from ya to parent of the new node
    return q;
}

//////////////////HELP FUNCTIONS/////////////////////
int readkey(FILE* fp){
    int key;
    fread(&key, sizeof(int), 1, fp);
    return key;
}

char readid(FILE* fp){
    char id;
    fread(&id, sizeof(char), 1, fp);
    return id;
}  

void printpreorder(Tnode* root, FILE* fw) {
    if (root == NULL) {
        return;
    }
    int rightbranch;
    int leftbranch;
    if(root->right == NULL){
        rightbranch = 0;
    }
    if(root->right != NULL){
        rightbranch = 1;
    }
    if(root->left == NULL){
        leftbranch = 0;
    }
    if(root->left != NULL){
        leftbranch = 2;
    }
    // fprintf(fw, "%d %d\n", root->key, rightbranch+leftbranch);
    int key = root->key;
    int RandL = rightbranch + leftbranch;
    fwrite(&key, sizeof(int), 1 , fw); //correct?
    fwrite(&RandL, sizeof(char), 1 , fw); //correct?
    printpreorder(root->left, fw);
    printpreorder(root->right, fw);
}

void freenode(Tnode* head){
	if(head == NULL) return;

	freenode(head -> left);
	freenode(head -> right);

	free(head);
}

Tnode* clock_rotation(Tnode* root){
    Tnode* newroot = root->left;
    root->left = newroot->right;
    newroot->right = root;
    return newroot;
}

Tnode* anticlock_rotation(Tnode* root){
    Tnode* newroot = root->right;
    root->right = newroot->left;
    newroot->left = root;
    return newroot;
}
