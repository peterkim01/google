#include "output.h"

///////////////OUTPUT 1/////////////////////
Node* post2tree(FILE* f){
    int numlabel, x, y;
    char label;
    
    Node* tree = NULL;
    Stack* curr = (struct Stack *)malloc(sizeof(Stack));

    while(!feof(f)){
        tree = (struct Node *)malloc(sizeof(Node));
        Stack* top = (struct Stack *)malloc(sizeof(Stack));

        if(fscanf(f, "%d(%d,%d)\n", &numlabel, &x, &y) == 3){
            tree->numlabel = numlabel;
            tree->x = x;
            tree->y = y;
            tree->label = '\0';
            tree->right = NULL;
            tree->left = NULL;

            top->node = tree;

            if(curr == NULL){
                curr = top;
            }else{
                top->next = curr;
                curr = top;
            }
                
        }else{
            fscanf(f, "%c\n",&label);
            tree->label = label;
            tree->numlabel = 0;
            tree->right = curr->node;
            pop(&curr);
            tree->left = curr->node;  
            pop(&curr);

            top->node = tree; 
            top->next = curr;
            curr = top;
        }
    }
    tree = curr->node;

    free(curr->next);
    free(curr);

    return(tree);
}

Node* leftright(Node* tree){
    while(1){
        if(tree->left->label && tree->left->right != NULL){ //check if I can reroot
            tree = rerootlr(tree);
        }
        else{
            return tree;
        }   
        if(tree->right->label && tree->right->left != NULL){
            tree = rerootrl(tree); 
        }
        else{
            return tree;
        }   
    }
}
///////////////END OF OUTPUT 1//////////////

///////////////////OUTPUT 2/////////////////
Node* rightleft(Node* tree){
    while(1){
        if(tree->right->label && tree->right->left != NULL){
            tree = rerootrl(tree); 
        }else{
            return tree;
        }
        if(tree->left->label && tree->left->right != NULL){ //check if I can reroot
            tree = rerootlr(tree);
        }
        else{
            return tree;
        }   
    } 
}
///////////////END OF OUTPUT 2//////////////

///////////////////OUTPUT 3/////////////////
void packing(Node* tree){     
    dimension(tree);
    rerootL(tree);
    rerootR(tree);
}

void rerootL(Node* tree){
    if(tree->left->numlabel){
        return;
    } 
    
    tree = rerootll(tree);
    dim_RLandLL(tree, 1);
    rerootL(tree);
    tree = rerootrr(tree); //rewind
    dim_LRandRR(tree, 0);

    tree = rerootlr(tree);
    dim_LRandRR(tree, 1);
    rerootR(tree);
    tree = rerootlr(tree); //rewind
    dim_LRandRR(tree, 0);

    return; 
}

void rerootR(Node* tree){
    if(tree->right->numlabel){ // || tree->right->right->rootx
        return;
    }

    tree = rerootrr(tree);
    dim_LRandRR(tree, 1);
    rerootR(tree);
    tree = rerootll(tree);
    dim_RLandLL(tree, 0);

    tree = rerootrl(tree);
    dim_RLandLL(tree, 1);
    rerootL(tree);
    tree = rerootrl(tree);
    dim_RLandLL(tree, 0);    
    
    return;
}

void dim_RLandLL(Node* curr, int check){
    Node* child = curr->right;
    if(child->label == 'H'){
        child-> w = findmax(child->left->w, child->right->w);
        child-> h = child->left->h + child->right->h;
    }else if(child->label == 'V'){
        child->h = findmax(child->left->h, child->right->h);
        child->w = child->left->w + child->right->w;
    }
    // else{ //leaf node
    //     child->w = child->x;
    //     child->h = child->y;
    // }

    if(curr->label == 'H'){
        curr->w = findmax(curr->left->w, curr->right->w);
        curr->h = curr->left->h + curr->right->h;
    }else if(curr->label == 'V'){
        curr->h = findmax(curr->left->h, curr->right->h);
        curr->w = curr->left->w + curr->right->w;
    }
    
    if(check){
    curr->left->rootx = curr->w;
    curr->left->rooty = curr->h;
    }
}

void dim_LRandRR(Node* curr, int check){
    Node* child = curr->left;
    if(child->label == 'H'){
        child-> w = findmax(child->left->w, child->right->w);
        child-> h = child->left->h + child->right->h;
    }else if(child->label == 'V'){
        child->h = findmax(child->left->h, child->right->h);
        child->w = child->left->w + child->right->w;
    }
    // else{ //leaf node
    //     child->w = child->x;
    //     child->h = child->y;
    // }

    if(curr->label == 'H'){
        curr->w = findmax(curr->left->w, curr->right->w);
        curr->h = curr->left->h + curr->right->h;
    }else if(curr->label == 'V'){
        curr->h = findmax(curr->left->h, curr->right->h);
        curr->w = curr->left->w + curr->right->w;
    }

    if(check){
    curr->right->rootx = curr->w;
    curr->right->rooty = curr->h;
    }
}

void dimension(Node* curr){
    if(curr == NULL) return;

    dimension(curr->right);
    dimension(curr->left);

    if(curr->label == 'H'){
        curr->w = findmax(curr->left->w, curr->right->w);
        curr->h = curr->left->h + curr->right->h;

    }else if(curr->label == 'V'){
        curr->h = findmax(curr->left->h, curr->right->h);
        curr->w = curr->left->w + curr->right->w;
    }
    else{ //leaf node
        curr->w = curr->x;
        curr->h = curr->y;
    }
}

//rerooting 4 cases
Node* rerootrr(Node* tree){
    Node* ctree = tree->right;
    tree->right = ctree->left;
    ctree->left = tree;
    
    return ctree;
}

Node* rerootll(Node* tree){
    Node* ctree = tree->left;
    tree->left = ctree->right;
    ctree->right = tree;
    
    return ctree;
}

Node* rerootlr(Node* tree){
    Node* ctree = tree->left;
    tree->left = ctree->left;
    ctree->left = tree;
    
    return ctree;
}

Node* rerootrl(Node* tree){
    Node* ctree = tree->right;
    tree->right = ctree->right;
    ctree->right = tree;
    
    return ctree;
}

///////////////END OF OUTPUT 3//////////////

///////////////HELP FUNCTIONS///////////////
 void freenode(Node* head){
	if(head == NULL) return;

	freenode(head -> left);
	freenode(head -> right);

	free(head);
}

void pop(Stack** top){
    
    Stack* temp;
    temp = (*top);
    *top = (*top)->next;
    
    free(temp);
}

void printpre(Node* curr, FILE* fw){
    if(curr == NULL) return;

    if(curr->label == 'V' || curr->label == 'H'){
        fprintf(fw, "%c\n", curr->label);
    }
    else{
        fprintf(fw, "%d(%d,%d)\n", curr->numlabel, curr->x, curr->y);
    }

    printpre(curr->left, fw);
    printpre(curr->right, fw);
}

int findmax(int a, int b){
    if (a>b){
        return a;
    }
    return b;
}

void printdim(Node* curr, FILE* fdim){
    if(curr == NULL) return;

    if(curr->rootx != 0 && (curr->label == 'V' || curr->label == 'H')){
        fprintf(fdim, "%c(%d,%d)\n", curr->label, curr->rootx, curr->rooty);
    }
    else if(curr->rootx != 0){
        fprintf(fdim, "%d(%d,%d)\n", curr->numlabel, curr->rootx, curr->rooty);
    }
    else if(curr->label == 'V' || curr->label == 'H'){
        fprintf(fdim, "%c\n", curr->label);
    }else{
        fprintf(fdim, "%d\n", curr->numlabel);   
    }
    printdim(curr->left, fdim);
    printdim(curr->right, fdim);
}
