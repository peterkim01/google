#include "hbt.h"
#include "pa4.h"
#include <string.h>

//  gcc -g -std=c99 -pedantic -Wvla -Wall -Wshadow -o3 *.c -o pa4
// ./pa4 -e ./examples/tree3.b ./test.txt

int main(int argc, char* argv[]){
    if(argc < 2){
        fprintf(stderr, "\nInvalid number of input or ouput files");
        return EXIT_FAILURE;
    }

    FILE* fp = fopen(argv[2], "r");
    FILE* fw = fopen(argv[3], "wb");

    Tnode* tnode = NULL;

    if(strcmp(argv[1], "-b") == 0){ //build tree
        tnode = buildtree(fp);
        printpreorder(tnode, fw);
        // test(tnode);
        freenode(tnode);
    }else if(strcmp(argv[1], "-e") == 0){ //evaluate tree
        int valid = evaluate(fp);
        if(!valid){
            return EXIT_FAILURE;
        }
    }
    
    fclose(fp);
    fclose(fw);
    
    return EXIT_SUCCESS;
}
