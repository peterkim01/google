#include <stdio.h>
#include <stdlib.h>
#include "sequence.h"

long *Array_Load_From_File(char *filename, int *arr_size){
    long *bintoArr;
    FILE* fp = fopen(filename, "rb");

    //do I need to check if fp == NULL?
    fseek(fp, 0, SEEK_END);
    if(ftell(fp) == 0){ //check if file fp is empty or not opened
        *arr_size = 0;
        fclose(fp);
        return NULL;
    }
    else{
        *arr_size = ftell(fp) / sizeof(long);
        // printf("size : %d\n", *arr_size);
        rewind(fp);

        bintoArr = (long *)malloc(sizeof(long) * *arr_size);
        
        //return NULL if bintoArr fails
        for(int i = 0; i < *arr_size; i++){
            fread(&bintoArr[i], sizeof(long), 1, fp);
        }
    
        fclose(fp);
        return bintoArr;
    }
}

long Array_Save_To_File(char *filename, long *array, int size){
    long arrsize;
    FILE *fw = fopen(filename, "wb");

    if(array == NULL || sizeof(array) == 0){
        fw = NULL; //empty output file should be created. Is this how?
        fclose(fw);
        return 0;
    }
    else{
        fwrite(array, sizeof(long), size, fw);
        fseek(fw, 0, SEEK_END);
        arrsize = ftell(fw) / sizeof(long);
        
        fclose(fw);
        return arrsize;
    }
    
}

void Array_Shellsort(long* array, int size, long* n_comp){
    int seq_size;
    long* seq = Generate_2p3q_Seq(size, &seq_size);

    for(int k = seq_size-1; k >= 0; k--){
        for(int j = seq[k]; j < size; j++){
            long temp = array[j];
            int i = j;
            while(i >= seq[k] && array[i-(seq[k])] > temp){
                (*n_comp)++;
                array[i] = array[i-(seq[k])];
                i = i-seq[k];
            }
            (*n_comp)++;
            array[i] = temp;
        }
    }
    free(seq);
}
