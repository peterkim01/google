from machine import TouchPad, Pin, Timer, deepsleep
import neopixel as n
import esp32
import network
import time
from time import gmtime
import machine
import socket
import struct

pressed = False
last_press_time = 0
debounce_time = 100
host = "pool.ntp.org"
timeout = 1
WL_time = -4  #West Lafayette is UTC-4


#################################### time
def read_time():
    NTP_QUERY = bytearray(48)
    NTP_QUERY[0] = 0x1B
    addr = socket.getaddrinfo(host, 123)[0][-1]
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.settimeout(timeout)
        s.sendto(NTP_QUERY, addr)
        msg = s.recv(48)
    finally:
        s.close()
    val = struct.unpack("!I", msg[40:44])[0]

    MIN_NTP_TIMESTAMP = 3913056000

    if val < MIN_NTP_TIMESTAMP:
        val += 0x100000000

    EPOCH_YEAR = gmtime(0)[0]
    if EPOCH_YEAR == 2000:
        NTP_DELTA = 3155673600
    elif EPOCH_YEAR == 1970:
        NTP_DELTA = 2208988800
    else:
        raise Exception("Unsupported epoch: {}".format(EPOCH_YEAR))

    return val - NTP_DELTA

def set_rtc():
    rtc = machine.RTC()    
    t = read_time()
    tm = gmtime(t)

    local_time = list(tm)
    local_time[3] += WL_time  

    if local_time[3] < 0:
        local_time[3] += 24
        local_time[2] -= 1 
    elif local_time[3] > 23:
        local_time[3] -= 24
        local_time[2] += 1 
    
    rtc.datetime((local_time[0], local_time[1], local_time[2], local_time[6] + 1, local_time[3], local_time[4], local_time[5], 0))

def print_date(timer):
    rtc = machine.RTC()
    current_time = rtc.datetime()
    print("-----------------------")
    print(f"Date: {current_time[1]:02}/{current_time[2]:02}/{current_time[0]:04}")
    print(f"Time: {current_time[4]:02}:{current_time[5]:02}:{current_time[6]:02} HRS")

####################################

################ WIFI
def connect_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    ssid = 'phasorphone'
    pwd = '12345678'
    
    if not wlan.isconnected():
        print('connecting to network...')
        wlan.connect(ssid, pwd)
        while not wlan.isconnected():
            pass
    print(f"Connected to {ssid}")
    print('IP Address:', wlan.ifconfig()[0])
################ 
    
    
############## button handler
def button_handler(pin):
    global pressed, last_press_time
    current_time = time.ticks_ms()
    if time.ticks_diff(current_time, last_press_time) > debounce_time:
        pressed = True
        last_press_time = current_time

############## button handler


############## Touch Pad handler
def setColor(r,g,b):
    np[0] = (r,g,b)
    np.write()


def control_NEO(timer):
    if t.read() < 110:       # touched --> Neo Pixel ON, Green
        setColor(0, 128, 0)
    else:                    #not touched --> Neo Pixel OFF        
        setColor(0,0,0)

##############
    
    

################ Sleep
def gotosleep(timer):
    global led_board
    print("I am going to sleep for 1 minute.")
    led_board.value(0)
    machine.deepsleep(60000)
    
################
        
external_button = Pin(36, Pin.IN, Pin.PULL_DOWN)
external_button.irq(trigger=Pin.IRQ_FALLING, handler=button_handler)

def main():
    global led_board
    led_board = machine.Pin(13, machine.Pin.OUT)
    led_board.value(1)
    connect_wifi()
    set_rtc()
    
    esp32.wake_on_ext0(pin=external_button, level=esp32.WAKEUP_ANY_HIGH)
    
    global np
    np = n.NeoPixel(Pin(0), 1)          # neopixel
    pin2 = Pin(2, Pin.OUT)              # pull this high to turn on np
    pin2.value(1)

    global t
    t = TouchPad(Pin(4))                # touchpad
    t.config(110)

    date_timer = Timer(0)      # timer 1
    date_timer.init(period=15000, mode=Timer.PERIODIC, callback=print_date)
    touchpad_timer = Timer(1)  # timer 2
    touchpad_timer.init(period=50, mode=Timer.PERIODIC, callback=control_NEO)
    sleep_timer = Timer(2)     # timer 3
    sleep_timer.init(period=30000, mode=Timer.PERIODIC, callback=gotosleep)
    
# Check if the wake-up was from deep sleep

#print(machine.wake_reason())
if machine.wake_reason() == machine.DEEPSLEEP_RESET:
    print("Woke up due to Timer wakeup.")
    machine.reset()
    
elif machine.wake_reason() == machine.PIN_WAKE:
    print("Woke up due to EXT0 wakeup.")
    machine.reset()
#else:
#    print("hmm")

main()

while True:
    pass
    #time.sleep(0.5)
    
