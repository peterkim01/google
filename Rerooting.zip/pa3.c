#include "output.h"

int main(int argc, char* argv[]){
    //gcc -g -std=c99 -Wall -Wshadow -Wvla -pedantic *.c -o pa3
    //valgrind --leak-check=full -s ./pa3 ./examples/8.po ./testlr.pr ./testrl.pr ./test.rdim
    
    if(argc != 5){
        // printf("\nargc: %d", argc);
        fprintf(stderr, "\nInvalid number of input or ouput files");
        return EXIT_FAILURE;
    }
    FILE* f = fopen(argv[1], "r");
    if(f == NULL){
        fprintf(stderr, "input 1 fopen unsuccessful");
        return EXIT_FAILURE;
    }
    FILE* fw = fopen(argv[2], "w");
    if(fw == NULL){
        fprintf(stderr, "\noutput 1 fopen unsuccessful\n");
        fclose(f);
        return EXIT_FAILURE;
    }
    FILE* fw2 = fopen(argv[3], "w");
    if(fw2 == NULL){
        fprintf(stderr, "\noutput 2 fopen unsuccessful\n");
        fclose(f);
        fclose(fw);
        return EXIT_FAILURE;
    }
    FILE* fdim = fopen(argv[4], "w");
    if(fdim == NULL){
        fprintf(stderr, "\noutput 3 fopen unsuccessful\n");
        fclose(f);
        fclose(fw);
        fclose(fw2);
        return EXIT_FAILURE;
    }

    Node* tree = post2tree(f);
    
    // output 1
    tree = leftright(tree);
    printpre(tree, fw);
    rewind(f);
    freenode(tree);
    tree = post2tree(f);
    // tree = leftright(tree); //reversing output 1

    //output 2
    tree = rightleft(tree);
    printpre(tree, fw2);
    rewind(f);
    freenode(tree);
    tree = post2tree(f);

    //output 3
    packing(tree);
    tree->rootx = 0;
    tree->rooty = 0;
    tree->right->rootx = 0;
    tree->left->rootx = 0;
    tree->right->rooty = 0;
    tree->left->rooty = 0;

    printdim(tree, fdim);

    freenode(tree);
    fclose(f);
    fclose(fw);
    fclose(fw2);
    fclose(fdim);
    return EXIT_SUCCESS;
}
