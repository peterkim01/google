#include <stdlib.h>
#include <stdio.h>

typedef struct Node {
   char label;
   int numlabel;
   int x;
   int y;
   int w; 
   int h;
   int rootx;
   int rooty;
   
   struct Node *left;
   struct Node *right;
} Node;

typedef struct Stack {
   struct Node *node;
   struct Stack *next;
} Stack;

void pop(Stack** top);
void printpre(Node* curr, FILE* fw);
Node* post2tree(FILE* f);
void freenode(Node* head);
Node* leftright(Node* tree);
Node* rightleft(Node* tree);
Node* rerootll(Node* tree);
Node* rerootrr(Node* tree);
Node* rerootlr(Node* tree);
Node* rerootrl(Node* tree);
void packing(Node* tree);
void dimension(Node* curr);
int findmax(int a, int b);
void printdim(Node* curr, FILE* fdim);
void rerootL(Node* tree);
void rerootR(Node* tree);
void dim_LRandRR(Node* curr, int check);
void dim_RLandLL(Node* curr, int check);