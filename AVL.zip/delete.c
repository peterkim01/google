#include "hbt.h"
#include "pa4.h"

Tnode* searchandbal(Tnode* root, Tnode* proot, int key){
    if(root == NULL) return root;
    int tempbal;
    if(key < (root->key)){
        // int child_d_height = 0;
        root->left = searchandbal((root->left), root, key);
        //if left subtree height decreases, decreaese balance of root
    }else if(key > root->key){
        // int child_d_height = 0;
        root->right = searchandbal((root->right), root, key);
        //if right subtree height decreases, increase balance of root
    }else{ //when key is found
        Tnode* temp = NULL;
        
        if(root->left == NULL || root->right == NULL){
            if(root->left != NULL && root->right == NULL){ //case 1 only left child
                temp = root->left;
                root = temp;
                root->left = NULL;
                root->balance--;
                tempbal = root->balance;
                free(temp);
            }
            else if(root->left == NULL && root->right != NULL){ //case 2 only right child
                temp = root->right;
                root = temp;
                root->right = NULL;
                root->balance++;
                tempbal = root->balance;
                free(temp);
            }
            else if(root->left == NULL && root->right == NULL){ //case 3 no child
                temp = root;
                root = NULL;
                free(temp);
            }
            else {
                fprintf(stderr, "ERROR! Unexpected control flow\n");
            }
        
        }else{                                             //case 4 both child
            temp = findimpred(root);
            root->key = temp->key; //replace keys
            root->right = searchandbal(root->right, root, root->key); 
            tempbal = root->balance;
        }
        if(root == NULL) return root;
    }

    //balance
    if(root->balance < 1 || root->balance > 1){
        root = balance(root, key);
        if(tempbal == -1 && root-> balance == 0){
            proot->balance--;
        }
        if(tempbal == 1 && root->balance == 0){
            proot->balance++;
        }
    }
    return root;
}

Tnode *balance(Tnode *pcurr, int key) {
    Tnode *curr = NULL; 
    Tnode *child = NULL;
    if (key > pcurr->key)
        child = pcurr->left;
    else
        child = pcurr->right;

    if ((pcurr->balance == 2) && (child->balance == 1)) { //case 1
        curr = clock_rotation(pcurr); 
        pcurr->balance = 0;
        child->balance = 0;
    }
    if ((pcurr->balance == -2) && (child->balance == -1)) { //case 2
        curr = anticlock_rotation(pcurr);
        pcurr->balance = 0;
        child->balance = 0;
    }
    
    if ((pcurr->balance == 2) && (child->balance == -1)) { //case 3
        pcurr->left = anticlock_rotation(child);
        curr = clock_rotation(pcurr);
        if (curr->balance == 0) {
            pcurr->balance = 0;
            child->balance = 0;
        }
        else {
            if(curr->balance == 1){
                pcurr->balance = -1;
                child->balance = 0;
            }
            else{
                pcurr->balance = 0;
                child->balance = 1;
            }
            curr->balance = 0;
        }
    }
    if((pcurr->balance == -2) && (child->balance == 1)){ //case 4
        pcurr->right = clock_rotation(child);
        curr = anticlock_rotation(pcurr);
        if (curr->balance == 0) {
            pcurr->balance = 0;
            child->balance = 0;
        }
        else {
            if (curr->balance == -1) {
                pcurr->balance = 1;
                child->balance = 0;
            }
            else {
                pcurr->balance = 0;
                child->balance = -1;
            }
            curr->balance = 0;
        }
    }
    if ((pcurr->balance == 2) && (child->balance == 0)){ //case 5
        curr = clock_rotation(pcurr); 
        pcurr->balance = -1;
        child->balance = -1;
    }
    if ((pcurr->balance == -2) && (child->balance == 0)){ //case 6
        curr = anticlock_rotation(pcurr);
        pcurr->balance = -1;
        child->balance = 1;
    }
    return curr;
}

Tnode* findimpred(Tnode* curr){
    curr = curr->left;
    while(curr != NULL){
        if(curr->right == NULL) return curr;
        curr = curr->right;
    }
    return curr;
}

// void test(Tnode* root){
//     if(root == NULL) return;

//     printf("%d(%d, %d)\n", root->key, root->left->key, root->right->key);
//     test(root->left);
//     test(root->right);
// }


/*
#include "hbt.h"
#include "pa4.h"

Tnode* searchandbal(Tnode* root, Tnode* proot, int key){
    if(root == NULL) return root;
    int tempbal;
    if(key < (root->key)){
        // int child_d_height = 0;
        root->left = searchandbal((root->left), root, key);
        //if left subtree height decreases, decreaese balance of root
    }else if(key > root->key){
        // int child_d_height = 0;
        root->right = searchandbal((root->right), root, key);
        //if right subtree height decreases, increase balance of root
    }else{ //when key is found
        Tnode* temp = NULL;
        
        if(root->left == NULL || root->right == NULL){
            if(root->left != NULL && root->right == NULL){ //case 1 no right child
                temp = root->left;
                root = temp;
                root->left = NULL;
                root->balance--;
                tempbal = root->balance;
                free(temp);
            }
            else if(root->left == NULL && root->right != NULL){ //case 2 no left child
                temp = root->right;
                root = temp;
                root->right = NULL;
                root->balance++;
                tempbal = root->balance;
                free(temp);
            }
            else if(root->left == NULL && root->right == NULL){ //case 3 no child
                temp = root;
                root = NULL;
                free(temp);
            }
            else {
                fprintf(stderr, "ERROR! Unexpected control flow\n");
            }
        
        }else{                                             //case 4 both child
            temp = findimpred(root);
            root->key = temp->key; //replace keys
            root->right = searchandbal(root->right, root, root->key); 
            tempbal = root->balance;
        }
        if(root == NULL) return root;
    }
    if(root->balance < 1 || root->balance > 1){
        root = balance(root, key);
        if(tempbal == -1 && root-> balance == 0){
            proot->balance--;
        }
        if(tempbal == 1 && root->balance == 0){
            proot->balance++;
        }
    }
    return root;
}
*/
