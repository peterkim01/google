Hardware conections
SCL connected to GPIO14, SDA connected to GPIO22

Demo link: https://youtu.be/lCQG8aFUdBk