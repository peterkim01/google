#include "pa5.h"

Pqueue* dijkstra(Vertex* graph, int s, int vcnt){
    int last_idx;
    if(s == 0){
        last_idx = vcnt-1;
    }else if(s != 0){
        last_idx = 0;
    }

    Pqueue* pq = buildPQ(graph, vcnt);
    pq[s].d = 0;
    
    while(last_idx >= 0 && last_idx <= (vcnt-1)){ //while PQ not empty
        Pqueue* u = extractmin(pq, last_idx, s, graph);
        if(s == 0){
        last_idx--;
        }else if(s != 0){
        last_idx++;
        }

        Nnode* curr = graph[u->vertex_idx].nnode;

        while(curr != NULL){
            int v = graph[curr->idx].idx;
            // printf("vertexidx: %d  pqvd: %d ud: %d currw %d\n", pq[v].vertex_idx, pq[v].d, u->d, curr->w);
            if(pq[v].d > u->d + curr->w){
                pq[v].d = u->d + curr->w;
                pq[v].pred = u->vertex_idx;
                upward_heapify(pq, v, last_idx, graph); 
            }
            curr = curr->nnode;
        }
    }
    // for(int i = 0; i < vcnt; i++){
    //     printf("-->vertexidx: %d pred: %d\n", pq[i].vertex_idx, pq[i].pred);
    // }
    return(pq);
}

// int find_vertex(Pqueue* pq, int v, int vcnt){ //find index of nnode in pq
//     int i;
//     for(i = 0; i <= vcnt; i++){
//         if(pq[i].vertex_idx == v) break;
//     }
//     return i;
// }
