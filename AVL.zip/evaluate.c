#include "hbt.h"
#include "pa4.h"
#include <limits.h>

int evaluate(FILE* fp){
    int inputcheck = 1;
    if(fp == NULL){
        printf("-1,0,0\n");
        return 0;
    }

    Tnode* tnode = readtree(fp);
    if(tnode == NULL){
        // printf("\n");
        freenode(tnode);
        printf("0,0,0\n");
        return (0);
    }

    int bstcheck = 1;
    checkbst(tnode, &bstcheck);
    int balcheck = 1;
    checkbal(tnode, &balcheck);

    printf("%d,%d,%d\n", inputcheck, bstcheck, balcheck);
    freenode(tnode);
    return(inputcheck == 1 ? 1 : 0);
}

void checkbst(Tnode* curr, int* bstcheck){
    if (curr == NULL) return;

    if (curr->left != NULL || curr->right != NULL){
        if(curr->left != NULL){
            if(curr->left->key > curr->key){
                *bstcheck = 0;
            }
        }else{
            if(curr->right->key < curr->key){
                *bstcheck = 0;
            }
        }
    } 

    checkbst(curr->left, bstcheck);
    checkbst(curr->right, bstcheck);
}

void checkbal(Tnode* curr, int* balcheck){
    if (curr == NULL) return;

    int balance = calcheight(curr->left) - calcheight(curr->right);

    if(balance <= -2 || balance >= 2){
        *balcheck = 0;
        return;
    }

    checkbal(curr->left, balcheck);
    checkbal(curr->right, balcheck); 
}

Tnode* readtree(FILE* fp){
    if(fp == NULL){
        return NULL;
    }
    int key;
    // char nodecheck;
    fread(&key, sizeof(int), 1, fp);
    char nodecheck = readid(fp);

    Tnode* newnode = malloc(sizeof(Tnode));
    newnode->key = key;
    newnode->left = NULL;
    newnode->right = NULL;

    if(nodecheck == 0){
        // newnode->balance = 0;
        return newnode;
    }else if(nodecheck == 1){
        // newnode->balance = -1;
        newnode->right = readtree(fp);
    }else if(nodecheck == 2){
        // newnode->balance = 1;
        newnode->left = readtree(fp);
    }else if(nodecheck == 3){
        // newnode->balance = 0;
        newnode->left = readtree(fp);
        newnode->right = readtree(fp);
    }else{
        return NULL;
    }
    
    return newnode;
}

int calcheight(Tnode* curr){
    if(curr == NULL){
        return -1;
    }

    int heightL = calcheight(curr->left);
    int heightR = calcheight(curr->right);

    if(heightL > heightR){
        return (++heightL);
    }
    else if(heightL <= heightR){
       return (++heightR);
    }else{
        fprintf(stderr, "unexpected flow\n");
        return 0;
    }
    
    return 0;
}
