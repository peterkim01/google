#include "pa5.h"
#include <limits.h>

Vertex* build_graph(char* filename, int *vcnt){
    int check_board;
    FILE* fp = fopen(filename, "r");
    if(fp == NULL){
        fprintf(stderr, "Incorrect input file format\n");
        return(NULL);
    }
    
    int n, m; //m rows, n columns
    int is_valid = fscanf(fp, "%d %d\n", &m, &n);
    if(is_valid == 0){
        fprintf(stderr, "improper rows and columns");
        return(NULL);
    }

    Vertex* graph = malloc((((m-1)*(n)+(m)*(n-1))+2) * sizeof(Vertex)); 

    graph[*vcnt].w = 0; //add source vertex
    graph[*vcnt].xcor = -1;
    graph[*vcnt].ycor = '\0';
    graph[*vcnt].idx = *vcnt;
    graph[*vcnt].nnode = NULL;
    *vcnt = *vcnt + 1;

    for(float i = 0; i <= (float)m-1; i=i+0.5){ //rows
        for(float j = 0; j <= (float)n - 1; j=j+0.5){ //columns
            if(i - (int)i == 0){ //add nodes at i = 0,1,2,3,4...
                
                if(j - (int)j != 0){ //add nodes at j = 0.5,1.5,2.5
                    graph[*vcnt].w = 1;
                    graph[*vcnt].xcor = j;
                    graph[*vcnt].ycor = i;
                    graph[*vcnt].idx = *vcnt;
                    *vcnt = *vcnt + 1;
                }
                
            }else{ //add nodes at i = 0.5,1.5,2.5,3.5...
                if(j - (int)j == 0){ //add nodes at j= 0,1,2,3
                    check_board = fgetc(fp);
                    if(check_board == '1'){
                        graph[*vcnt].w = 0;
                    }else if(check_board == '0'){
                        graph[*vcnt].w = 1;   
                    }
                    graph[*vcnt].xcor = j;
                    graph[*vcnt].ycor = i;
                    graph[*vcnt].idx = *vcnt;
                    *vcnt = *vcnt + 1;
                }
            }
        }
        if((int)i % 2 == 1) check_board = fgetc(fp); //after odd row, read one more time for \n
    }

    graph[*vcnt].w = 1; //add destination vertex
    graph[*vcnt].xcor = n;
    graph[*vcnt].ycor = '\0';
    graph[*vcnt].idx = *vcnt;
    graph[*vcnt].nnode = NULL;
    *vcnt = *vcnt + 1;

    /////////////////MAKE ADJ LIST////////////////////
    for(int k = 0; k < *vcnt; k++){
        
        graph[k].nnode = NULL;
        Nnode* curr = NULL;
        Nnode* newnode;

        if(graph[k].xcor == 0){ //connect source node to first node of each column
            graph->check_first = 1; //vertex connected to source
            newnode = (Nnode*)malloc(sizeof(Nnode));
            newnode->idx = graph[k].idx;
            if(graph[k].w == 0){
                newnode->w = 0;
            }else{
                newnode->w = 1;
            }
            
            newnode->nnode = NULL;
            Nnode* curr2 = graph[0].nnode;

            if(curr2 == NULL){
                graph[0].nnode = newnode;
            }else{
                while(curr2->nnode != NULL){
                    curr2 = curr2->nnode;
                }
                curr2->nnode = newnode;
            }
        }

        if(k != 0 && k != *vcnt-1){ //exclude source and destination node
        graph->check_first = 0; //vertex not connected to source
        
        if(graph[k].xcor-0.5 >= 0 && graph[k].ycor -0.5 >= 0){ //top left vertex exists
            newnode = (Nnode*)malloc(sizeof(Nnode));
            newnode->idx = k-n;
            newnode->w = 1;
            if(graph[k].w == 0 && graph[newnode->idx].w == 0){
                newnode->w = 0;
            }else if(graph[k].w == 1 && graph[newnode->idx].w == 0){
                newnode->w = 0;
            }
            newnode->nnode = NULL;

            curr = graph[k].nnode;
            if(curr == NULL){
                graph[k].nnode = newnode;
            }else{
                while(curr->nnode != NULL){
                    curr = curr->nnode;
                }
                curr->nnode = newnode;
            }
        }
        if(graph[k].xcor+0.5 <= n-1 && graph[k].ycor -0.5 >= 0){ //top right vertex exists
            newnode = (Nnode*)malloc(sizeof(Nnode));
            newnode->idx = k-(n-1);
            newnode->w = 1;
            if(graph[k].w == 0 && graph[newnode->idx].w == 0){
                newnode->w = 0;
            }else if(graph[k].w == 1 && graph[newnode->idx].w == 0){
                newnode->w = 0;
            }
            newnode->nnode = NULL;

            curr = graph[k].nnode;
            if(curr == NULL){
                graph[k].nnode = newnode;
            }else{
                while(curr->nnode != NULL){
                    curr = curr->nnode;
                }
                curr->nnode = newnode;
            }
        }
        if(graph[k].xcor-0.5 >= 0 && graph[k].ycor +0.5 <= m-1){ //bottom left vertex exists
            newnode = (Nnode*)malloc(sizeof(Nnode));
            newnode->idx = k+(n-1);
            newnode->w = 1;
            if(graph[k].w == 0 && graph[newnode->idx].w == 0){
                newnode->w = 0;
            }else if(graph[k].w == 1 && graph[newnode->idx].w == 0){
                newnode->w = 0;
            }
            newnode->nnode = NULL;

            curr = graph[k].nnode;
            if(curr == NULL){
                graph[k].nnode = newnode;
            }else{
                while(curr->nnode != NULL){
                    curr = curr->nnode;
                }
                curr->nnode = newnode;
            }
        }
        if(graph[k].xcor+0.5 <= n-1 && graph[k].ycor+0.5 <= m-1){ //bottom right vertex exists
            newnode = (Nnode*)malloc(sizeof(Nnode));
            newnode->idx = k+n;
            newnode->w = 1;
            if(graph[k].w == 0 && graph[newnode->idx].w == 0){
                newnode->w = 0;
            }else if(graph[k].w == 1 && graph[newnode->idx].w == 0){
                newnode->w = 0;
            }
            newnode->nnode = NULL;
            
            curr = graph[k].nnode;
            if(curr == NULL){
                graph[k].nnode = newnode;
            }else{
                while(curr->nnode != NULL){
                    curr = curr->nnode;
                }
                curr->nnode = newnode;
            }
        }

        if(k-n-(n-1) > 0 && graph[k-n-(n-1)].w == 0){  //&& graph[k].w == 0
            
            newnode = (Nnode*)malloc(sizeof(Nnode));
            newnode->idx = k-n-(n-1);
            // printf("1idx: %d\n", newnode->idx);
            newnode->w = 0;
            newnode->nnode = NULL;

            curr = graph[k].nnode;
            if(curr == NULL){
                graph[k].nnode = newnode;
            }else{
                while(curr->nnode != NULL){
                    curr = curr->nnode;
                }
                curr->nnode = newnode;
            }
        }
        if(k+n+(n-1) < *vcnt-1 && graph[k+n+(n-1)].w == 0){
            newnode = (Nnode*)malloc(sizeof(Nnode));
            newnode->idx = k+n+(n-1);
            // printf("2idx: %d\n", newnode->idx);
            newnode->w = 0;
            newnode->nnode = NULL;

            curr = graph[k].nnode;
            if(curr == NULL){
                graph[k].nnode = newnode;
            }else{
                while(curr->nnode != NULL){
                    curr = curr->nnode;
                }
                curr->nnode = newnode;
            }
        }

        if(graph[k].xcor == n-1){ //connect destination node to last node of each column
            newnode = (Nnode*)malloc(sizeof(Nnode));
            newnode->idx = graph[*vcnt-1].idx;
            newnode->w = 1;
            newnode->nnode = NULL;
            Nnode* curr2 = graph[k].nnode;
            
            if(curr2 == NULL){
                graph[k].nnode = newnode;
            }else{
                while(curr2->nnode != NULL){
                    curr2 = curr2->nnode;
                }
                curr2->nnode = newnode;
            }

            // newnode = (Nnode*)malloc(sizeof(Nnode));
            // newnode->idx = graph[k].idx;
            // newnode->w = 1;
            // newnode->nnode = NULL;
            // Nnode* curr3 = graph[*vcnt-1].nnode;

            // if(curr3 == NULL){
            //     graph[*vcnt-1].nnode = newnode;
            // }else{
            //     while(curr3->nnode != NULL){
            //         curr3 = curr3->nnode;
            //     }
            //     curr3->nnode = newnode;
            // }
        }

        }
    }

    fclose(fp);
    return(graph);
}

Pqueue* buildPQ(Vertex* graph, int vcnt){
    Pqueue* pq = malloc(vcnt * sizeof(Pqueue));
    for(int i = 0; i<vcnt; i++){
        pq[i].d = SHRT_MAX;
        pq[i].pred = SHRT_MIN; //NULL
        // pq[i].idx = i;
        pq[i].vertex_idx = i;
    }
    return pq;
}

Pqueue* extractmin(Pqueue* pq, int last_idx, int s, Vertex* graph){ 
    
    graph[pq[s].vertex_idx].idx = last_idx;
    graph[pq[last_idx].vertex_idx].idx = s;
    swap(pq, s, last_idx);
    
    downward_heapify(pq, s, last_idx-1, graph);

    // printf("last_idx: %d\n", last_idx);
    // for(int i = 0; i <= 13 ; i++){
    //     printf("i: %d pq vertex idx: %d, heap idx: %d\n",i, pq[i].vertex_idx, graph[pq[i].vertex_idx].idx);
    // }
    // printf("------------------------\n");

    return &pq[last_idx];
}

void downward_heapify(Pqueue* pq, int i, int n, Vertex* graph){
    // printf("downward\n");
    
    Pqueue temp_2 = (pq[i]);
    // Pqueue* temp = &(pq[i]);

    int j = 2*i+1;
    while(j <= n){
        if(j < n && pq[j].d > pq[j+1].d){
            j++;
        }
        if(temp_2.d <= pq[j].d){ //min heap complete
            break;
        }else{
            pq[i] = pq[j];
            graph[pq[i].vertex_idx].idx = i;
            i = j;
            j = 2*i + 1;
        }
    }
    pq[i] = temp_2;
    graph[pq[i].vertex_idx].idx = i;
}

void upward_heapify(Pqueue* pq, int n, int last_idx, Vertex* graph){
    Pqueue new = pq[n];
    int child = n;
    int parent = (child-1) / 2;

    while(child <= last_idx && child > 0 && pq[parent].d > new.d){
        pq[child] = pq[parent];
        graph[pq[child].vertex_idx].idx = child;
        child = parent;
        parent = (child-1) / 2;
    }
    pq[child] = new;
    graph[pq[child].vertex_idx].idx = child;
}

void swap(Pqueue* pq, int x, int y){
    Pqueue temp = pq[x];
    pq[x] = pq[y];
    pq[y] = temp;
}
